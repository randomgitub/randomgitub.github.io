function quiz() {


var question1 = prompt("Grand Central Terminal, Park Avenue, New York is the world's");
if (question1 === "largest railway station") {
  alert("Correct");
} else {
  alert("you suck");
}

var question2 = prompt("Entomology is the science that studies");

if (question2 === "Insects") {
  alert("yay");
} else {
  alert("you are unworthy of being trump junior");
}
  
var question3 = prompt("Escape velocity of a rocket fired from the earth towards the moon is a velocity to get rid of the");

if (question3 === "Earths gravitational pull") {
  alert("correctttt!");
} else {
  alert("I always knew you never had it in you");
}
  
var question4 = prompt(" 	Coral reefs in India can be found in");
if (question4 === "Rameshwaram") {
  alert("cake will be served - from glados");
} else {
  alert("neurotoxin will be administered-glados");

  var question5 = prompt("The ozone layer restricts");
  if(question4 === "Ultraviolet radiation") {
    alert("you are correct");
  } else {
    alert("incorrect");
  }
  var question6 = prompt("Filaria is caused by");
  if (question6 === "Mosquito") {
    alert("corrrect");
  } else {
    alert("you suck");
  }
  var question7 = prompt("During World War II, when did Germany attack France?");
  if (question7 === "1940") {
    alert( correct );
  } else {
    alert("jhjk");
  }
  var question8 = prompt("Headquarters of UNO are situated at");
  if (question8 === "New York, USA") {
    alert("correct");
  } else {
    alert("wronggggg");
  } 
  var question9 = prompt ("First International Peace Congress was held in London in");
  if(question9 === "1843 AD") {
    alert("correct");
  } else{
    alert ("..........");
  }
  var question10 = prompt ("For seeing objects at the surface of water from a submarine under water, the instrument used is");
  if(question10 === "periscope") {
    alert("correct");
  } else {
    alert("incorect");
  }
}
  
}